// Developed by the CigarProject //

var logMessages = {

	info: function(str) {
		console.debug("[INFO]", str);
	},

	warn: function(str) {
		console.warn("[WARN]", str);
	},

	err: function(str) {
		console.error("[ERROR] ", str);
	},

	debug: function(str) {
		console.info("[DEBUG] ", str);
	}

}