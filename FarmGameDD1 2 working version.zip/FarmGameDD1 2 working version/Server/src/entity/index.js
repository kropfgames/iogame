module.exports = {
    Cell: require('./Cell'),
    PlayerCell: require('./PlayerCell'),
    Food: require('./Food'),
    Cow: require('./Cow'),
    Pig: require('./Pig'),
    Virus: require('./Virus'),
    HumanEnemy: require('./HumanEnemy'),
    MotherCell: require('./MotherCell'),
    EjectedMass: require('./EjectedMass'),
};
