var Cell = require('./Cell');
var Packet = require('../packet');
 
 
/*
canEat
getSpeed
onAdd to server - this.color = this.owner.color
*/
class PlayerCell extends Cell 
{
    constructor(server, owner, position, size, firstPlayerCell, color, order) 
    {
        super(server, owner, position, size);
        this.type = 0;
        this._canRemerge = false;
        this.firstPlayerCell = firstPlayerCell;
        this.color = color;
        this.order = order
        //this.playerType = this.playerType; //undefined
        
    };

    canEat(cell) 
    {
        return true;
    };

    getSpeed(dist) 
    {
        let speed = 2.2 * Math.pow(this._size, -0.45) * 40;
        //let speed = 2.2 * Math.pow(this._size, -0.45) * 30;
      
        speed *= this.server.config.playerSpeed;
        speed = Math.min(dist, speed);
      
        if (dist != 0) 
        {
          speed /= dist;
        }
      
        return speed;
    };
  
 
    onAdd(server) 
    {

        //pushes this player cell to all cells
        this.owner.cells.push(this);
      
        //sends a new node as a packet
        this.owner.socket.packetHandler.sendPacket(new Packet.AddNode(this.owner, this));
      
        //unshifts the player cell from the nodes player
        this.server.nodesPlayer.unshift(this);
      
        //sends a message to the server that the cell has been added
        server.mode.onCellAdd(this);
    }
  
    onRemove(server) 
    {
        let index = this.owner.cells.indexOf(this);
      
        if (index != -1)
            this.owner.cells.splice(index, 1);
      
        index = this.server.nodesPlayer.indexOf(this);

        if (index != -1)
            this.server.nodesPlayer.splice(index, 1);

        server.mode.onCellRemove(this);
    };
  
};

module.exports = PlayerCell;
