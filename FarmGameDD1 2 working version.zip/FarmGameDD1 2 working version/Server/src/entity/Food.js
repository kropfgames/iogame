const Cell = require('./Cell');

//adds and removes the food from the game
class Food extends Cell 
{
    constructor(server, owner, position, size) 
    {
        super(server, owner, position, size);
      
       this.type = 4;
      
        this.overrideReuse = false;
      
    }; //constructor
      
    onAdd(server) 
    {
        server.nodesFood.push(this);
    };
 
    onRemove(server) 
    {
        const index = server.nodesFood.indexOf(this);
      
        //spawn a new food at the same position as the player + a random x and y position
        //force the food to follow the player
      
      
        if (index != -1) 
        {
            server.nodesFood.splice(index, 1);
        };

        if (!this.overrideReuse)
        {
            server.spawnFood();
        }
      
      //server.emit(onateFood);
      
      //send the server a message
      server.mode.onCellRemove(this);
    };
  
}; //Food

module.exports = Food;