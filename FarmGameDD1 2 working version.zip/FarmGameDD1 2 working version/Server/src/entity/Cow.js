const Cell = require('./Cell');
const Food = require('./Food');

//adds and removes the food from the game
class Cow extends Cell 
{
    constructor(server, owner, position, size) 
    {
        super(server, owner, position, size);
        this.type = 5;
        //this.overrideReuse = false;

    }; //constructor
      
    onAdd(server) 
    {
        server.nodesFood.push(this);
    };

    onRemove(server) 
    {
        const index = server.nodesFood.indexOf(this);
      
        if (index != -1) 
        {
            server.nodesFood.splice(index, 1);
        };

        if (!this.overrideReuse)
        {
            server.spawnCow();
        }
    };
  
};  

//module.exports = Cell;
module.exports = Cow;
